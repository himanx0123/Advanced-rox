package com.rox.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.IOException
import java.util.Locale

class RoxService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    companion object {
        const val CH = "rox"
        // Hindi model "Rox" ko in roopon mein likh sakta hai
        val WAKE = listOf("रॉक्स", "रोक्स", "रॉकस", "रोकस", "rocks", "rox", "रॉक")
    }

    private var speech: SpeechService? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var loading = false
    private val handler = Handler(Looper.getMainLooper())
    private var awakeUntil = 0L
    private lateinit var brain: Brain

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        brain = Brain(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Rox", NotificationManager.IMPORTANCE_LOW))
        val n = buildNote("Rox तैयार हो रहा है…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (speech == null && !loading) {
            loading = true
            StorageService.unpack(this, "model-hi", "model",
                { model: Model -> startRecognizer(model) },
                { e: IOException -> note("मॉडल लोड नहीं हुआ: " + e.message) })
        }
        return START_STICKY
    }

    private fun startRecognizer(model: Model) {
        try {
            val rec = Recognizer(model, 16000.0f)
            val s = SpeechService(rec, 16000.0f)
            s.startListening(this)
            speech = s
            note("Rox सुन रहा है — बोलो \"Rox\"")
            speak("रॉक्स तैयार है")
        } catch (e: Exception) {
            note("Error: " + e.message)
        }
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        val r = t.setLanguage(Locale("hi", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            note("Settings > Text-to-speech में Hindi voice डाउनलोड करो")
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { resume() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { resume() }
        })
        ttsReady = true
    }

    private fun resume() {
        handler.postDelayed({ speech?.setPause(false) }, 300)
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        speech?.setPause(true)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rox")
    }

    private fun beep() {
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 90).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (_: Exception) {}
    }

    // ---- Vosk callbacks ----
    override fun onResult(hypothesis: String?) {
        if (hypothesis == null) return
        val text = try { JSONObject(hypothesis).optString("text") } catch (e: Exception) { "" }
        handle(text.trim())
    }

    override fun onPartialResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) { note("Error: " + exception?.message) }
    override fun onTimeout() {}

    private fun handle(t: String) {
        if (t.isEmpty()) return
        val now = System.currentTimeMillis()
        val lower = t.lowercase()
        note("सुना: $t")
        val hasWake = WAKE.any { lower.contains(it) }
        if (hasWake) {
            var cmd = lower
            for (w in WAKE) cmd = cmd.replace(w, " ")
            cmd = cmd.trim()
            if (cmd.isEmpty()) {
                beep()
                awakeUntil = now + 8000
            } else {
                run(cmd)
            }
        } else if (now < awakeUntil) {
            awakeUntil = 0
            run(lower)
        }
    }

    private fun run(cmd: String) {
        speak(brain.process(cmd))
    }

    // ---- Notification ----
    private fun buildNote(text: String): Notification =
        Notification.Builder(this, CH)
            .setContentTitle("Rox")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun note(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNote(text))
    }

    override fun onDestroy() {
        speech?.stop()
        speech?.shutdown()
        tts?.shutdown()
        super.onDestroy()
    }
}
