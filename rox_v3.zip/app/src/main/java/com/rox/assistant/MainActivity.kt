package com.rox.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun addButton(l: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { action() }
        l.addView(b)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(48, 100, 48, 48)

        val info = TextView(this)
        info.textSize = 16f
        info.text = "Rox v3\n\n" +
                "ऊपर से नीचे एक-एक बटन करो:\n" +
                "1) App info → ⋮ → Allow restricted settings (अगर दिखे)\n" +
                "2) Battery, Notification access, Accessibility चालू करो\n" +
                "3) फिर Rox चालू करो और permissions Allow करो\n" +
                "4) बोलो: Rox, टाइम बता"
        l.addView(info)

        addButton(l, "▶ Rox चालू करो") { begin() }
        addButton(l, "⏹ Rox बंद करो") {
            stopService(Intent(this@MainActivity, RoxService::class.java))
        }
        addButton(l, "App info (restricted settings के लिए)") {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + this@MainActivity.packageName)
                )
            )
        }
        addButton(l, "Battery: Unrestricted") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        addButton(l, "Notification access (नोटिफिकेशन पढ़ने के लिए)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        addButton(l, "Accessibility (फोन कंट्रोल के लिए)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val sv = ScrollView(this)
        sv.addView(l)
        setContentView(sv)
    }

    private fun begin() {
        val need = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) launchService()
        else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchService()
        } else {
            Toast.makeText(this, "Mic permission ज़रूरी है", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchService() {
        startForegroundService(Intent(this, RoxService::class.java))
        Toast.makeText(this, "Rox चालू हो रहा है…", Toast.LENGTH_LONG).show()
    }
}
