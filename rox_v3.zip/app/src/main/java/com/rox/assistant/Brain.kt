package com.rox.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.CallLog
import java.util.Calendar

class Brain(private val ctx: Context) {

    fun process(cmd: String): String {
        val s = cmd.lowercase().trim() + " "
        return try {
            when {
                isQuery(s) -> query(s)
                has(s, "लॉक", "lock") -> lockPhone()
                has(s, "फ्लैश", "फ़्लैश", "फ्लेश", "टॉर्च", "टार्च", "flash", "torch") -> torch(s)
                has(s, "हॉटस्पॉट", "हॉट स्पॉट", "हॉटस्पोट", "hotspot") -> hotspot()
                has(s, "वाईफाई", "वाई फाई", "वाई-फाई", "वायफाई", "वाईफ़ाई", "wifi", "wi-fi", "wi fi") -> wifi(s)
                has(s, "तारीख", "तारिख", "दिनांक", "date") -> date()
                has(s, "टाइम", "समय", "कितने बजे", "क्या बजा", "time") -> time()
                else -> "मैं नोटिफिकेशन, कॉल, टाइम, तारीख, लॉक, फ्लैश, वाईफाई और हॉटस्पॉट कर सकता हूँ"
            }
        } catch (e: Exception) {
            "कुछ गड़बड़ हो गई"
        }
    }

    private fun has(s: String, vararg k: String): Boolean = k.any { s.contains(it) }

    private val offWords = arrayOf("बंद", "ऑफ", "off", "बुझा", "हटा")

    // ---------------- Time / Date ----------------
    private fun time(): String {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val p = when {
            h < 12 -> "सुबह"
            h < 16 -> "दोपहर"
            h < 20 -> "शाम"
            else -> "रात"
        }
        return if (m == 0) "अभी $p के $h12 बजे हैं" else "अभी $p के $h12 बजकर $m मिनट हुए हैं"
    }

    private fun date(): String {
        val c = Calendar.getInstance()
        val days = listOf("रविवार", "सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार")
        val months = listOf(
            "जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून",
            "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
        )
        return "आज ${days[c.get(Calendar.DAY_OF_WEEK) - 1]} है, " +
                "${c.get(Calendar.DAY_OF_MONTH)} ${months[c.get(Calendar.MONTH)]} ${c.get(Calendar.YEAR)}"
    }

    // ---------------- Lock / Flash / WiFi / Hotspot ----------------
    private fun lockPhone(): String {
        val a = RoxAccess.instance ?: return "पहले Accessibility में Rox Control को चालू करो"
        if (Build.VERSION.SDK_INT < 28) return "यह फोन में सपोर्ट नहीं है"
        a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        return "फोन लॉक कर दिया"
    }

    private fun torch(s: String): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "फ्लैश नहीं मिला"
        val off = has(s, *offWords)
        cm.setTorchMode(id, !off)
        return if (off) "फ्लैश बंद कर दिया" else "फ्लैश चालू कर दिया"
    }

    private fun wifi(s: String): String {
        val a = RoxAccess.instance ?: return "पहले Accessibility में Rox Control को चालू करो"
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val isOn = wm.isWifiEnabled
        val wantOn = !has(s, *offWords)
        if (has(s, "बंद", "ऑफ", "off", "चालू", "ऑन", "on", "खोल") && wantOn == isOn) {
            return if (isOn) "वाईफाई पहले से चालू है" else "वाईफाई पहले से बंद है"
        }
        a.toggleTile(listOf("Wi-Fi", "WLAN", "WiFi", "वाई-फ़ाई", "वाई-फाई"))
        return if (isOn) "वाईफाई बंद कर रहा हूँ" else "वाईफाई चालू कर रहा हूँ"
    }

    private fun hotspot(): String {
        val a = RoxAccess.instance ?: return "पहले Accessibility में Rox Control को चालू करो"
        a.toggleTile(listOf("Hotspot", "Personal hotspot", "Portable hotspot", "हॉटस्पॉट"))
        return "हॉटस्पॉट का बटन दबा रहा हूँ"
    }

    // ---------------- Notifications / Call log ----------------
    private val APPS = listOf(
        listOf("यूट्यूब", "youtube") to "com.google.android.youtube",
        listOf("व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप", "व्हाट्स", "whatsapp") to "com.whatsapp",
        listOf("इंस्टाग्राम", "instagram") to "com.instagram.android",
        listOf("फेसबुक", "facebook") to "com.facebook.katana",
        listOf("टेलीग्राम", "telegram") to "org.telegram.messenger",
        listOf("जीमेल", "gmail") to "com.google.android.gm"
    )

    private fun isQuery(s: String): Boolean =
        has(s, "किसने", "किसका", "किसकी", "किसके", "कौन", "क्या आया", "आया ", "आई ", "आए ", "आयी ",
            "नोटिफिकेशन", "notification", "नोटिफ")

    private fun query(s: String): String =
        if (has(s, "कॉल", "call", "फोन", "फ़ोन", "काल")) callLog(s) else notifs(s)

    private fun notifs(s: String): String {
        val list = RoxNotifService.snapshot()
            ?: return "पहले Notification access में Rox को चालू करो"
        var pkg: String? = null
        for ((keys, p) in APPS) if (keys.any { s.contains(it) }) pkg = p
        val f = list.filter { pkg == null || it.pkg == pkg }.take(5)
        if (f.isEmpty()) return "कोई नई नोटिफिकेशन नहीं है"
        return f.joinToString(". ") { "${it.app} पर ${it.title}: ${it.text.take(100)}" }
    }

    private fun callLog(s: String): String {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED)
            return "कॉल लॉग की permission दो"
        val missed = has(s, "मिस", "छूट", "missed")
        val cur = ctx.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
            null, null, CallLog.Calls.DATE + " DESC"
        ) ?: return "कॉल लॉग नहीं मिला"
        val out = ArrayList<String>()
        cur.use { c ->
            while (c.moveToNext() && out.size < 3) {
                val type = c.getInt(2)
                if (missed && type != CallLog.Calls.MISSED_TYPE) continue
                val nm = c.getString(1)
                val who = if (!nm.isNullOrBlank()) nm else (c.getString(0) ?: "अनजान नंबर")
                val kind = when (type) {
                    CallLog.Calls.INCOMING_TYPE -> "आया"
                    CallLog.Calls.OUTGOING_TYPE -> "गया"
                    CallLog.Calls.MISSED_TYPE -> "मिस्ड"
                    else -> ""
                }
                val cal = Calendar.getInstance()
                cal.timeInMillis = c.getLong(3)
                val h = cal.get(Calendar.HOUR_OF_DAY)
                val h12 = if (h % 12 == 0) 12 else h % 12
                out.add("$who का कॉल $kind, $h12 बजकर ${cal.get(Calendar.MINUTE)} मिनट पर")
            }
        }
        if (out.isEmpty()) return if (missed) "कोई मिस्ड कॉल नहीं है" else "कोई कॉल नहीं मिला"
        return out.joinToString(". ")
    }
}
