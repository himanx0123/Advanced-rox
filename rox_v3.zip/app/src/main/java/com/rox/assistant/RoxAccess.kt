package com.rox.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RoxAccess : AccessibilityService() {

    companion object {
        @Volatile
        var instance: RoxAccess? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    private val h = Handler(Looper.getMainLooper())

    // Quick Settings kholo, tile dabao, phir band karo
    fun toggleTile(cands: List<String>) {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        h.postDelayed({
            tap(cands)
            h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 700)
        }, 1000)
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val out = ArrayList<String>()
        collect(root, out)
        return out.joinToString(", ").take(300)
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (n == null || out.size >= 20) return
        val t = n.text?.toString() ?: n.contentDescription?.toString()
        if (!t.isNullOrBlank()) out.add(t)
        for (i in 0 until n.childCount) collect(n.getChild(i), out)
    }

    fun tap(cands: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        for (c in cands) {
            if (c.isBlank()) continue
            val nodes = root.findAccessibilityNodeInfosByText(c)
            for (node in nodes) {
                var n: AccessibilityNodeInfo? = node
                while (n != null && !n.isClickable) n = n.parent
                if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = findScrollable(root) ?: return false
        return n.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val r = findScrollable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }
}
