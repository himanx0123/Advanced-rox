package com.rox.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class NotifItem(val pkg: String, val app: String, val title: String, val text: String, val time: Long)

class RoxNotifService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: RoxNotifService? = null

        // null = notification access chalu nahi hai
        fun snapshot(): List<NotifItem>? {
            val s = instance ?: return null
            return try {
                s.activeNotifications
                    .filter {
                        it.packageName != s.packageName &&
                                (it.notification.flags and Notification.FLAG_ONGOING_EVENT) == 0 &&
                                (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0
                    }
                    .sortedByDescending { it.postTime }
                    .map { toItem(s, it) }
            } catch (e: Exception) {
                null
            }
        }

        private fun toItem(s: RoxNotifService, sbn: StatusBarNotification): NotifItem {
            val ex = sbn.notification.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            val app = try {
                val pm = s.packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (e: Exception) {
                sbn.packageName
            }
            return NotifItem(sbn.packageName, app, title, text, sbn.postTime)
        }
    }

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
    }
}
